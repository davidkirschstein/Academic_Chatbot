
var mysql = require();
var express = require('express');
var bdp = require('body-parser');

const express = require('express');
const { exec } = require('child_process');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/data', express.static(path.join(__dirname, 'data')));


app.get('/index', (req, res) => {
    res.render('index', {  });
});
app.get('/base', (req, res) => {
    res.render('base', {  });
});


// Route to execute app.py
app.get('/python/app', (req, res) => {
    const scriptPath = path.join(__dirname, 'python', 'app.py');

    exec('python ${scriptPath}', (error, stdout, stderr) => {
        if (error) {
            console.error('Error: ${error.message}');
            res.status(500).send('Internal Server Error');
            return;
        }
        console.log('Python script output: ${stdout}');
        res.send('Python script output: ${stdout}');
    });
});

app.listen(port, (8000) => {
    console.log('Server is running on http://localhost:${8000}' );
});